<?php
	include("include/common.php");
	include("$config[template_path]/user_top.html");
?>
<br>
<table width="100%" border="0" cellspacing="1" cellpadding="0" bgcolor="#9cbee6"><tr><td>
<table width="100%" border="0" cellspacing="1" cellpadding="8" bgcolor="#ffffff"><tr><td>
<p align="justify"></p>
<p align="justify">Our team is ready to help you with all of your 
  questions and needs. <br />

                              <br />
                              <img src="http://www.eaglebusinessbrokers.com/images/icon2.gif" alt="" />   <span class="blue_font"><strong>Phone
                              Number:</strong></span> (303) 743-7303<br />
              <img src="http://www.eaglebusinessbrokers.com/images/icon2.gif" alt="" /> <span class="blue_font"><strong>Fax
      Number:</strong></span> (303) 873-9068<br />
              <img src="http://www.eaglebusinessbrokers.com/images/icon2.gif" alt="" />  <font class="blue_font"><strong>E-mail Addresses:</strong></font> <font color="#42557B" size="2"><a href="mailto:meabraham@msn.com">meabraham@msn.com</a></font><br />
              <br />
              <img src="http://www.eaglebusinessbrokers.com/images/icon2.gif" alt="" />   <font class="blue_font"><strong>Mailing
  Address:</strong></font> <font color="#42557B" size="2">3443 S Galena Street - Suite 210</font>, <font color="#42557B" size="2">Denver, CO 80231<br>
  </font></p>
<br><p align="justify"></p><br><br><br><br><br><center> </center><br><br></td></tr></table></td></tr></table>
<br></td>
<?php
	include("$config[template_path]/user_bottom.html");
?>
