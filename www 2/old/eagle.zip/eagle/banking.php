<?php
	include("include/common.php");
	include("$config[template_path]/user_top.html");
?><style type="text/css">
<!--
.style55 {color: #003366}
-->
</style>
<span class="style55">
	<p>If you are looking for banking resources please do not hesitate to call our
office, we would be happy to refer you to some of our trusted associates.  You can contact us as (303) 734-7304.</span> </p>
	