<?
	header("Location:result.html");
?>