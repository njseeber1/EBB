<?php


	include("include/common.php");

	
	include("$config[template_path]/user_top.html");
?>

	<table border="<? echo $style[admin_listing_border] ?>" cellspacing="<? echo $style[admin_listing_cellspacing] ?>" cellpadding="<? echo $style[admin_listing_cellpadding] ?>" width="<? echo $style[admin_table_width] ?>" class="form_main">
		<FONT COLOR="#666666" <P>
Here at Eagle Business Brokers our focal point is on the customer.  We have an established reputation throughout Colorado for being able to find solid investment opportunities for our clients looking to purchase a business.  We also have a very special relationship with our investors looking to sell businesses.  
<P>
<P>
Often business owners build up small empires in their community�s and eventually wish to sell and retire to enjoy the fruits of their labor.  This is where we come in, we have numerous investors coming to us and we provide a safe and professional market place for investments. 
<P>
<P>
Our goal is to try to find good fits between our clients.  We provide support and protection throughout the entire process, since this is the key focal point of our enterprise we are the experts in our market and you can be assured that the transactions will be handled in a professional and through manner.  
<P>
<P>
Purchasing a business is a very complex process, it is important that nothing is left to chance, every detail is considered, after all there are hundreds of thousands to millions of dollars at stake, be sure to have professionals on your side who are looking out for your interests during the transaction.
</font>
 
			

			<h3>&nbsp;</h3>
		  </td>
		</tr>
	</table>

<?



	include("$config[template_path]/user_bottom.html");
?>