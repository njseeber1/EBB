<?php

/**
 * vCard.class
 *
 * Copyright (c) 2003-2004 The SquirrelMail Project Team
 * Licensed under the GNU GPL. For full terms see the file COPYING.
 *
 * This (will) contain functions needed to vCards.
 *
 * http://www.imc.org/pdi/vcard-21.txt
 *
 * $Id: VCard.class.php,v 1.3.2.1 2004/02/24 15:57:13 kink Exp $
 */


class VCard {

function create_vcard ($value_array) {

return $vcard;
}

function parse_vcard ($vcard) {

return $array;
}

}

?>
