<?php

   function compatibility_version()
   {
      return '1.3';
   }

?>
