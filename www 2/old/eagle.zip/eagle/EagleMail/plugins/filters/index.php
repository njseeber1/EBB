<?php

   /**
    **  index.php -- Displays the main frameset
    **
    **  Copyright (c) 1999-2003 The SquirrelMail development team
    **  Licensed under the GNU GPL. For full terms see the file COPYING.
    **
    **  Redirects to the login page.
    **
    **  $Id: index.php,v 1.5 2003/10/27 22:24:39 tassium Exp $
    * @package plugins
    * @subpackage filters
    **/

   header("Location:../../src/login.php\n\n");
   exit();

?>
